<template>
  <div id="header" class="col-lg-12">
    <img src="../../../static/img/二倍率icon切图/logo@2x.png" height="50%" width="40%"style="margin-top: .12rem"/>
    <i class="el-icon-search"></i>
  </div>
</template>

<script>
  export default {
    data(){
      return{

      }
    }
  }
</script>

<style scoped lang="scss">
  #header{
    height: .45rem;
    /*background-color: #122b40;*/
    i{
      font-size: .15rem;
      line-height: .45rem;
      float: right;
      margin-right: .32rem;
    }
  }
</style>
